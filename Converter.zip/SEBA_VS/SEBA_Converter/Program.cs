﻿using System;
using System.Diagnostics;
using System.IO;

namespace SEBA_Converter
{
    class Program
    {
        static string CubeBlockData1 =
            "            <MyObjectBuilder_CubeBlock xsi:type=\"MyObjectBuilder_TextPanel\">\n" +
            "              <SubtypeName>TransparentLCDSmall</SubtypeName>\n" +
            "              <EntityId>";

        static string CubeBlockData2 =
            "</EntityId>\n" +
            "              <Min ";

        static string CubeBlockData3 =
            " />\n" +
            "              <ComponentContainer>\n" +
            "                <Components>\n" +
            "                  <ComponentData>\n" +
            "                    <TypeId>MyModStorageComponent</TypeId>\n" +
            "                    <Component xsi:type=\"MyObjectBuilder_ModStorageComponent\">\n" +
            "                      <Storage>\n" +
            "                        <dictionary>\n" +
            "                          <item>\n" +
            "                            <Key>74de02b3-27f9-4960-b1c4-27351f2b06d1</Key>\n" +
            "                            <Value>";

        static string CubeBlockData4 =
            "</Value>\n" +
            "                          </item>\n" +
            "                        </dictionary>\n" +
            "                      </Storage>\n" +
            "                    </Component>\n" +
            "                  </ComponentData>\n" +
            "                </Components>\n" +
            "              </ComponentContainer>\n" +
            "              <CustomName>Data_";

        static string CubeBlockData5 =
            "</CustomName>\n" +
            "              <ShowOnHUD>false</ShowOnHUD>\n" +
            "              <ShowInTerminal>true</ShowInTerminal>\n" +
            "              <ShowInToolbarConfig>true</ShowInToolbarConfig>\n" +
            "              <ShowInInventory>true</ShowInInventory>\n" +
            "              <Enabled>true</Enabled>\n" +
            "              <Description />\n" +
            "              <Title>Title</Title>\n" +
            "              <AccessFlag>READ_AND_WRITE_FACTION</AccessFlag>\n" +
            "              <ChangeInterval>0</ChangeInterval>\n" +
            "              <Font Type=\"MyObjectBuilder_FontDefinition\" Subtype=\"Debug\" />\n" +
            "              <FontSize>8</FontSize>\n" +
            "              <PublicDescription>Bank\n";

        static string CubeBlockData6 =
            "</PublicDescription>\n" +
            "              <PublicTitle>Public title</PublicTitle>\n" +
            "              <ShowText>NONE</ShowText>\n" +
            "              <FontColor>\n" +
            "                <PackedValue>4294967295</PackedValue>\n" +
            "                <X>255</X>\n" +
            "                <Y>255</Y>\n" +
            "                <Z>255</Z>\n" +
            "                <R>255</R>\n" +
            "                <G>255</G>\n" +
            "                <B>255</B>\n" +
            "                <A>255</A>\n" +
            "              </FontColor>\n" +
            "              <BackgroundColor>\n" +
            "                <PackedValue>4278190080</PackedValue>\n" +
            "                <X>0</X>\n" +
            "                <Y>0</Y>\n" +
            "                <Z>0</Z>\n" +
            "                <R>0</R>\n" +
            "                <G>0</G>\n" +
            "                <B>0</B>\n" +
            "                <A>255</A>\n" +
            "              </BackgroundColor>\n" +
            "              <CurrentShownTexture>0</CurrentShownTexture>\n" +
            "              <ContentType>TEXT_AND_IMAGE</ContentType>\n" +
            "              <SelectedScript />\n" +
            "              <TextPadding>0</TextPadding>\n" +
            "              <Version>1</Version>\n" +
            "              <ScriptBackgroundColor>\n" +
            "                <PackedValue>4288108544</PackedValue>\n" +
            "                <X>0</X>\n" +
            "                <Y>88</Y>\n" +
            "                <Z>151</Z>\n" +
            "                <R>0</R>\n" +
            "                <G>88</G>\n" +
            "                <B>151</B>\n" +
            "                <A>255</A>\n" +
            "              </ScriptBackgroundColor>\n" +
            "              <ScriptForegroundColor>\n" +
            "                <PackedValue>4294962611</PackedValue>\n" +
            "                <X>179</X>\n" +
            "                <Y>237</Y>\n" +
            "                <Z>255</Z>\n" +
            "                <R>179</R>\n" +
            "                <G>237</G>\n" +
            "                <B>255</B>\n" +
            "                <A>255</A>\n" +
            "              </ScriptForegroundColor>\n" +
            "              <Sprites>\n" +
            "                <Length>0</Length>\n" +
            "              </Sprites>\n" +
            "            </MyObjectBuilder_CubeBlock>\n";

        static byte[] FileBuffer;
        static byte[] ImgBin;

        static int FrameNum = 1;
        static int BankSize = 0;
        static int BankNum = 0;
        static int BlockPX = 0;
        static int BlockPY = 0;
        static int BlockPZ = 0;
        static string CustomData = "";
        static string FinalFileData = "";

        static int rgb(byte r, byte g, byte b)
        {
            return (int)(0xe100 + (r << 6) + (g << 3) + b);
        }
        static void Main(string[] args)
        {
            DirectoryInfo TargetFolder = new DirectoryInfo("D:/BadAppleProjs/SEBA/");
            if (!TargetFolder.Exists)
                return;

            var ThisProcess = Process.GetCurrentProcess();
            ThisProcess.PriorityClass = ProcessPriorityClass.High;

            foreach (FileInfo ThisFile in TargetFolder.GetFiles())
            {
                if (ThisFile.FullName.EndsWith(".bmp"))
                {
                    using (FileStream File = new FileStream(ThisFile.FullName, FileMode.Open, FileAccess.Read))
                    {
                        try
                        {
                            FileBuffer = new byte[File.Length];
                            File.Read(FileBuffer, 0, (int)File.Length);
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }

                    Console.WriteLine(ThisFile.FullName);
                    ImgBin = MyImageConverter.BitmapToBinary24(FileBuffer);
                    ImgBin = MyImageConverter.Binary24ToGray4(ImgBin);
                    //CustomData += Gray4ToRLEStr(ImgBin, (FrameNum % 2 == 1));
                    CustomData += Gray4ToRLEStr(ImgBin, true);
                    CustomData += Gray4ToRLEStr(ImgBin, false);

                    FrameNum++;

                    if (BankSize > 59200)
                    {
                        BankSize = 0;
                        FinalFileData += CubeBlockData1 + $"{123456 + BankNum}" + CubeBlockData2 + $"x=\"{BlockPX}\" y=\"{-BlockPY}\" z=\"{-BlockPZ}\"" + CubeBlockData3 + CustomData + CubeBlockData4 + $"{BankNum}" + CubeBlockData5 + $"{BankNum}" + CubeBlockData6;

                        BlockPX++;
                        if (BlockPX > 9)
                        {
                            BlockPX = 0;
                            BlockPY++;
                        }
                        if (BlockPY > 9)
                        {
                            BlockPY = 0;
                            BlockPZ++;
                        }

                        BankNum++;

                        CustomData = "";
                        Console.WriteLine($"Bank {BankNum} ------------------------");
                    }
                }
            }

            FinalFileData += CubeBlockData1 + $"{123456 + BankNum}" + CubeBlockData2 + $"x=\"{BlockPX}\" y=\"{-BlockPY}\" z=\"{-BlockPZ}\"" + CubeBlockData3 + CustomData + CubeBlockData4 + $"{BankNum}" + CubeBlockData5 + $"{BankNum}" + CubeBlockData6;
            Console.WriteLine($"Bank {BankNum + 1} ------------------------");

            System.Threading.Thread.Sleep(1000);
            ThrowFile("Result");
            return;
        }
        
        static string Gray4ToRLEStr(byte[] ImgData, bool OddFrame = true, int ImgWidth = 160)
        {
            long PtrOrig = 0;
            int PosX = 0;

            byte CurByte = 0;
            byte ByteCount = 0;

            string OutputStr = "";

            if (!OddFrame)
                PtrOrig += ImgWidth / 4;

            CurByte = ImgData[PtrOrig];
            OutputStr += CurByte.ToString("X02");

            while (PtrOrig < ImgData.Length)
            {
                PtrOrig++;
                PosX++;
                if (PosX >= ImgWidth / 4)
                {
                    PosX = 0;
                    PtrOrig += ImgWidth / 4;

                    if (PtrOrig >= ImgData.Length)
                        break;
                }

                if (CurByte != ImgData[PtrOrig] || ByteCount == 255)
                {
                    OutputStr += ByteCount.ToString("X02");
                    ByteCount = 0;
                    CurByte = ImgData[PtrOrig];
                    OutputStr += CurByte.ToString("X02");

                    continue;
                }

                ByteCount++;
            }

            OutputStr += ByteCount.ToString("X02") + $"\n";

            BankSize += OutputStr.Length;
            return OutputStr;
        }

        static void ThrowFile(string Name)
        {
            FileStream OutputFile = System.IO.File.Create(AppDomain.CurrentDomain.BaseDirectory + Name + ".txt");
            OutputFile.Close();
            OutputFile.Dispose();

            StreamWriter Writer = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + Name + ".txt", false);
            Writer.Write(FinalFileData);
        }
    }
}
